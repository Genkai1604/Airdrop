import puppeteer from 'puppeteer-core';
const browser = await puppeteer.connect({
  browserWSEndpoint: 'ws://your-remote-server-ip:9222/devtools/browser/<id>',
});
import fs from 'fs';
import path from 'path';
import proxyChain from 'proxy-chain';
import dotenv from 'dotenv';
import colors from 'colors';

dotenv.config();
class Gradient {
  constructor() {
    this.accounts = [];
    this.extensionId = "caacbgbklghmpodbdafajbgdnegacfmo";
    this.USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36";
    this.ALLOW_DEBUG = process.env.ALLOW_DEBUG === "True";
    this.EXTENSION_FILENAME = "app.crx";
  }

  loadData() {
    try {
      const accountsFile = fs.readFileSync("accounts.json", "utf8");
      const accountsData = JSON.parse(accountsFile);
      this.accounts.push(...accountsData);
    } catch (err) {
      logMess("-> Không tìm thấy tệp account.json, sử dụng env", "warning");
      if (process.env.APP_USER && process.env.APP_PASS) {
        this.accounts.push({
          user: process.env.APP_USER,
          password: process.env.APP_PASS,
          proxy: process.env.PROXY,
        });
      }
    }
  }

  async getBrowserOptions(account) {
    const options = {
      headless: true, // Chạy ở chế độ không giao diện
      executablePath: '/home/userland/Airdrop/CP/chromium', // Đường dẫn mới đến Chromium
      args: [
        `--user-agent=${this.USER_AGENT}`,
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-web-security',
        '--disable-features=IsolateOrigins,site-per-process',
      ],
    };

    if (account.proxy) {
      logMess(`-> Thiết lập proxy cho ${account.user}:`, account.proxy);
      let proxyUrl = account.proxy;
      if (!proxyUrl.includes("://")) {
        proxyUrl = `http://${proxyUrl}`;
      }
      const newProxyUrl = await proxyChain.anonymizeProxy(proxyUrl);
      logMess("-> URL proxy mới:", newProxyUrl);
      options.args.push(`--proxy-server=${newProxyUrl}`);
    }

    return options;
  }

  async runAccount(account) {
    logMess(`-> Bắt đầu tài khoản ${account.user}...`);

    const browserOptions = await this.getBrowserOptions(account);

    let browser;
    try {
      browser = await puppeteer.launch(browserOptions);
      const page = await browser.newPage();

      logMess(`-> Trình duyệt đã bắt đầu cho ${account.user}`);

      logMess(`-> Đăng nhập ${account.user}...`);
      await page.goto('https://app.gradient.network/', { waitUntil: 'networkidle2' });

      await page.type('[placeholder="Enter Email"]', account.user);
      await page.type('[type="password"]', account.password);
      await page.click('button');

      await page.waitForXPath('//*[contains(text(), "Copy Referral Link")]', { timeout: 30000 });

      logMess(`-> ${account.user} đã đăng nhập thành công!`, "success");

      await page.goto(`chrome-extension://${this.extensionId}/popup.html`);
      await page.waitForXPath('//div[contains(text(), "Status")]', { timeout: 30000 });

      // Check for region availability
      const regionUnavailable = await page.$x('//*[contains(text(), "Sorry, Gradient is not yet available in your region.")]');
      if (regionUnavailable.length > 0) {
        logMess(`-> ${account.user}: Gradient not available in region`, "warning");
        await browser.close();
        return;
      }

      logMess(`-> ${account.user} đang chạy...`, "info");
    } catch (error) {
      console.error(`Error with account ${account.user}:`, error);
      if (browser) {
        await browser.close();
      }
    }
  }

  async main() {
    console.log("Tool được phát triển bởi nhóm tele Airdrop Hunter Siêu Tốc (https://t.me/airdrophuntersieutoc)".yellow);
    this.loadData();

    const promises = this.accounts.map((account) => this.runAccount(account));
    await Promise.all(promises);
  }
}

function logMess(msg, type = "info") {
  const timestamp = new Date().toLocaleTimeString();
  switch (type) {
    case "success":
      console.log(`[${timestamp}] [*] ${msg}`.green);
      break;
    case "custom":
      console.log(`[${timestamp}] [*] ${msg}`.magenta);
      break;
    case "error":
      console.log(`[${timestamp}] [!] ${msg}`.red);
      break;
    case "warning":
      console.log(`[${timestamp}] [*] ${msg}`.yellow);
      break;
    default:
      console.log(`[${timestamp}] [*] ${msg}`.blue);
  }
}

const client = new Gradient();
client.main().catch((err) => {
  logMess(err.message, "error");
  process.exit(1);
});
