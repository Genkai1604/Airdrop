import random

# Danh sách hệ điều hành và kiến trúc
operating_systems = [
    "Windows NT 10.0; Win64; x64",
    "Windows NT 10.0; WOW64",
    "Windows NT 6.1; Win64; x64",
    "Windows NT 6.1; WOW64",
    "Macintosh; Intel Mac OS X 10_15_7",
    "Macintosh; Intel Mac OS X 11_2_3",
    "X11; Linux x86_64",
    "X11; Linux i686"
]

# Hàm tạo danh sách user agent
def generate_user_agents(num_agents):
    user_agents = []
    for _ in range(num_agents):
        os = random.choice(operating_systems)
        chrome_version = f"{random.randint(85, 120)}.0.{random.randint(4000, 4999)}.{random.randint(0, 200)}"
        user_agent = f"Mozilla/5.0 ({os}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_version} Safari/537.36"
        user_agents.append(user_agent)
    return user_agents

# Tạo 100 user agent và lưu vào file user.txt
user_agents = generate_user_agents(100)
with open("user.txt", "w") as file:
    for agent in user_agents:
        file.write(agent + "\n")

print("Đã lưu 100 User-Agent vào file user.txt")