# -*- coding: utf-8 -*-
import asyncio
import ssl
import json
import time
import uuid
from loguru import logger
import websockets

async def connect_to_wss(user_id, proxy, user_agent):
    device_id = str(uuid.uuid4())
    logger.info(f"Using proxy: {proxy} with User-Agent: {user_agent}")
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    uri = "wss://proxy.wynd.network:4444/"

    while True:  # Vòng lặp cho từng proxy và user agent
        try:
            custom_headers = {
                "User-Agent": user_agent
            }

            # Tách proxy thành ip và port
            proxy_ip, proxy_port = proxy.split(':')
            proxy_uri = f"ws://{proxy_ip}:{proxy_port}"

            async with websockets.connect(uri, ssl=ssl_context, extra_headers={
                "Origin": "chrome-extension://lkbnfiajjmbhnfledhphioinpickokdi",
                "User-Agent": custom_headers["User-Agent"],
                "Proxy-Connection": "keep-alive"
            }, ping_interval=None) as websocket:  # tắt ping tự động

                async def send_ping():
                    while True:
                        send_message = json.dumps(
                            {"id": str(uuid.uuid4()), "version": "1.0.0", "action": "PING", "data": {}})
                        logger.debug(send_message)
                        await websocket.send(send_message)
                        await asyncio.sleep(30)  # Đặt khoảng thời gian mong muốn

                send_ping_task = asyncio.create_task(send_ping())
                try:
                    while True:
                        response = await websocket.recv()
                        message = json.loads(response)
                        logger.info(message)
                        if message.get("action") == "AUTH":
                            auth_response = {
                                "id": message["id"],
                                "origin_action": "AUTH",
                                "result": {
                                    "browser_id": device_id,
                                    "user_id": user_id,
                                    "user_agent": custom_headers['User-Agent'],
                                    "timestamp": int(time.time()),
                                    "device_type": "extension",
                                    "version": "4.20.2",
                                    "extension_id": "lkbnfiajjmbhnfledhphioinpickokdi"
                                }
                            }
                            logger.debug(auth_response)
                            await websocket.send(json.dumps(auth_response))

                        elif message.get("action") == "PONG":
                            pong_response = {"id": message["id"], "origin_action": "PONG"}
                            logger.debug(pong_response)
                            await websocket.send(json.dumps(pong_response))
                finally:
                    send_ping_task.cancel()

        except Exception as e:
            logger.error(f"Error with proxy {proxy} and User-Agent {user_agent}: {str(e)}")
            break  # Ngắt vòng lặp cho proxy này và chuyển sang proxy tiếp theo

async def main():
    user_id = '2nQUPOKhUwgkp4qNatcBYqlrguk'  # Thay bằng User ID của bạn

    # Đọc proxy từ tệp proxy.txt
    with open('proxy.txt', 'r') as f:
        proxies = [line.strip() for line in f.readlines() if line.strip()]

    # Đọc user agent từ tệp user.txt
    with open('user.txt', 'r') as f:
        user_agents = [line.strip() for line in f.readlines() if line.strip()]

    proxy_count = len(proxies)
    user_agent_count = len(user_agents)

    # Lặp vô hạn qua các proxy và user agent
    while True:
        for i in range(max(proxy_count, user_agent_count)):
            proxy = proxies[i % proxy_count]  # Lặp lại nếu hết proxy
            user_agent = user_agents[i % user_agent_count]  # Lặp lại nếu hết user agent
            await connect_to_wss(user_id, proxy, user_agent)

if __name__ == '__main__':
    asyncio.run(main())
